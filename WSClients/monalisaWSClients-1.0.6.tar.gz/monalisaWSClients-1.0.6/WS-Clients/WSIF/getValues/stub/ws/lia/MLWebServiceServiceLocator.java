/**
 * MLWebServiceServiceLocator.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.3 Aug 02, 2005 (02:07:42 CEST) WSDL2Java emitter.
 */

package ws.lia;

public class MLWebServiceServiceLocator extends org.apache.axis.client.Service implements ws.lia.MLWebServiceService {

    public MLWebServiceServiceLocator() {
    }


    public MLWebServiceServiceLocator(org.apache.axis.EngineConfiguration config) {
        super(config);
    }

    public MLWebServiceServiceLocator(java.lang.String wsdlLoc, javax.xml.namespace.QName sName) throws javax.xml.rpc.ServiceException {
        super(wsdlLoc, sName);
    }

    // Use to get a proxy class for MLWebService
    private java.lang.String MLWebService_address = "http://mickyt.rogrid.pub.ro:6004/axis/services/MLWebService";

    public java.lang.String getMLWebServiceAddress() {
        return MLWebService_address;
    }

    // The WSDD service name defaults to the port name.
    private java.lang.String MLWebServiceWSDDServiceName = "MLWebService";

    public java.lang.String getMLWebServiceWSDDServiceName() {
        return MLWebServiceWSDDServiceName;
    }

    public void setMLWebServiceWSDDServiceName(java.lang.String name) {
        MLWebServiceWSDDServiceName = name;
    }

    public ws.lia.MLWebService getMLWebService() throws javax.xml.rpc.ServiceException {
       java.net.URL endpoint;
        try {
            endpoint = new java.net.URL(MLWebService_address);
        }
        catch (java.net.MalformedURLException e) {
            throw new javax.xml.rpc.ServiceException(e);
        }
        return getMLWebService(endpoint);
    }

    public ws.lia.MLWebService getMLWebService(java.net.URL portAddress) throws javax.xml.rpc.ServiceException {
        try {
            ws.lia.MLWebServiceSoapBindingStub _stub = new ws.lia.MLWebServiceSoapBindingStub(portAddress, this);
            _stub.setPortName(getMLWebServiceWSDDServiceName());
            return _stub;
        }
        catch (org.apache.axis.AxisFault e) {
            return null;
        }
    }

    public void setMLWebServiceEndpointAddress(java.lang.String address) {
        MLWebService_address = address;
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        try {
            if (ws.lia.MLWebService.class.isAssignableFrom(serviceEndpointInterface)) {
                ws.lia.MLWebServiceSoapBindingStub _stub = new ws.lia.MLWebServiceSoapBindingStub(new java.net.URL(MLWebService_address), this);
                _stub.setPortName(getMLWebServiceWSDDServiceName());
                return _stub;
            }
        }
        catch (java.lang.Throwable t) {
            throw new javax.xml.rpc.ServiceException(t);
        }
        throw new javax.xml.rpc.ServiceException("There is no stub implementation for the interface:  " + (serviceEndpointInterface == null ? "null" : serviceEndpointInterface.getName()));
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(javax.xml.namespace.QName portName, Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        if (portName == null) {
            return getPort(serviceEndpointInterface);
        }
        java.lang.String inputPortName = portName.getLocalPart();
        if ("MLWebService".equals(inputPortName)) {
            return getMLWebService();
        }
        else  {
            java.rmi.Remote _stub = getPort(serviceEndpointInterface);
            ((org.apache.axis.client.Stub) _stub).setPortName(portName);
            return _stub;
        }
    }

    public javax.xml.namespace.QName getServiceName() {
        return new javax.xml.namespace.QName("urn:lia.ws", "MLWebServiceService");
    }

    private java.util.HashSet ports = null;

    public java.util.Iterator getPorts() {
        if (ports == null) {
            ports = new java.util.HashSet();
            ports.add(new javax.xml.namespace.QName("urn:lia.ws", "MLWebService"));
        }
        return ports.iterator();
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(java.lang.String portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        
if ("MLWebService".equals(portName)) {
            setMLWebServiceEndpointAddress(address);
        }
        else 
{ // Unknown Port Name
            throw new javax.xml.rpc.ServiceException(" Cannot set Endpoint Address for Unknown Port" + portName);
        }
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(javax.xml.namespace.QName portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        setEndpointAddress(portName.getLocalPart(), address);
    }

}
