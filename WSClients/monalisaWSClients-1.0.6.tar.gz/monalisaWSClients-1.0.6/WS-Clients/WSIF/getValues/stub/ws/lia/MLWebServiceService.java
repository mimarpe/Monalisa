/**
 * MLWebServiceService.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.3 Aug 02, 2005 (02:07:42 CEST) WSDL2Java emitter.
 */

package ws.lia;

public interface MLWebServiceService extends javax.xml.rpc.Service {
    public java.lang.String getMLWebServiceAddress();

    public ws.lia.MLWebService getMLWebService() throws javax.xml.rpc.ServiceException;

    public ws.lia.MLWebService getMLWebService(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
