/**
 * WSCluster.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.3 Aug 02, 2005 (02:07:42 CEST) WSDL2Java emitter.
 */

package lia.ws;

public class WSCluster  implements java.io.Serializable {
    private java.lang.String clusterName;

    private lia.ws.WSNode[] nodeList;

    public WSCluster() {
    }

    public WSCluster(
           java.lang.String clusterName,
           lia.ws.WSNode[] nodeList) {
           this.clusterName = clusterName;
           this.nodeList = nodeList;
    }


    /**
     * Gets the clusterName value for this WSCluster.
     * 
     * @return clusterName
     */
    public java.lang.String getClusterName() {
        return clusterName;
    }


    /**
     * Sets the clusterName value for this WSCluster.
     * 
     * @param clusterName
     */
    public void setClusterName(java.lang.String clusterName) {
        this.clusterName = clusterName;
    }


    /**
     * Gets the nodeList value for this WSCluster.
     * 
     * @return nodeList
     */
    public lia.ws.WSNode[] getNodeList() {
        return nodeList;
    }


    /**
     * Sets the nodeList value for this WSCluster.
     * 
     * @param nodeList
     */
    public void setNodeList(lia.ws.WSNode[] nodeList) {
        this.nodeList = nodeList;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof WSCluster)) return false;
        WSCluster other = (WSCluster) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.clusterName==null && other.getClusterName()==null) || 
             (this.clusterName!=null &&
              this.clusterName.equals(other.getClusterName()))) &&
            ((this.nodeList==null && other.getNodeList()==null) || 
             (this.nodeList!=null &&
              java.util.Arrays.equals(this.nodeList, other.getNodeList())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getClusterName() != null) {
            _hashCode += getClusterName().hashCode();
        }
        if (getNodeList() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getNodeList());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getNodeList(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(WSCluster.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://ws.lia", "WSCluster"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("clusterName");
        elemField.setXmlName(new javax.xml.namespace.QName("", "clusterName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nodeList");
        elemField.setXmlName(new javax.xml.namespace.QName("", "nodeList"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://ws.lia", "WSNode"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
