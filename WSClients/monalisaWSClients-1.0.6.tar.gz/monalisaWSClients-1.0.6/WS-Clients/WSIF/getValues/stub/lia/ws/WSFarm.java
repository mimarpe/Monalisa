/**
 * WSFarm.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.3 Aug 02, 2005 (02:07:42 CEST) WSDL2Java emitter.
 */

package lia.ws;

public class WSFarm  implements java.io.Serializable {
    private lia.ws.WSCluster[] clusterList;

    private java.lang.String farmName;

    public WSFarm() {
    }

    public WSFarm(
           lia.ws.WSCluster[] clusterList,
           java.lang.String farmName) {
           this.clusterList = clusterList;
           this.farmName = farmName;
    }


    /**
     * Gets the clusterList value for this WSFarm.
     * 
     * @return clusterList
     */
    public lia.ws.WSCluster[] getClusterList() {
        return clusterList;
    }


    /**
     * Sets the clusterList value for this WSFarm.
     * 
     * @param clusterList
     */
    public void setClusterList(lia.ws.WSCluster[] clusterList) {
        this.clusterList = clusterList;
    }


    /**
     * Gets the farmName value for this WSFarm.
     * 
     * @return farmName
     */
    public java.lang.String getFarmName() {
        return farmName;
    }


    /**
     * Sets the farmName value for this WSFarm.
     * 
     * @param farmName
     */
    public void setFarmName(java.lang.String farmName) {
        this.farmName = farmName;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof WSFarm)) return false;
        WSFarm other = (WSFarm) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.clusterList==null && other.getClusterList()==null) || 
             (this.clusterList!=null &&
              java.util.Arrays.equals(this.clusterList, other.getClusterList()))) &&
            ((this.farmName==null && other.getFarmName()==null) || 
             (this.farmName!=null &&
              this.farmName.equals(other.getFarmName())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getClusterList() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getClusterList());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getClusterList(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getFarmName() != null) {
            _hashCode += getFarmName().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(WSFarm.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://ws.lia", "WSFarm"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("clusterList");
        elemField.setXmlName(new javax.xml.namespace.QName("", "clusterList"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://ws.lia", "WSCluster"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("farmName");
        elemField.setXmlName(new javax.xml.namespace.QName("", "farmName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
