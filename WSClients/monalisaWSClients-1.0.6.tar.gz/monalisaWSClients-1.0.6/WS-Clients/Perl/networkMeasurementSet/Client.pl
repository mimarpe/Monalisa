#!/usr/bin/perl -w

use SOAP::Lite;

    if (@ARGV==6 || @ARGV==5) { 

	# create the service
	# call the function
	#   - ARGV[0] - characteristic Name
	#   - ARGV[1] - source service name
	#   - ARGV[2] - destination service name
	#   - ARGV[3] - fromTime [yyyy-MM-dd'T'HH:mm:ss]
	#   - ARGV[4] - toTime [yyyy-MM-dd'T'HH:mm:ss]
	#   - ARGV[5] - URL of the MLWebService - optional
	
	# get results
	$SERVICE_LOCATION="";
	if (@ARGV==6) {
	    $SERVICE_LOCATION=$ARGV[5];
	} else {
	    $SERVICE_LOCATION=`../../../conf/MWS.sh`;
	}
     	
	 $result = SOAP::Lite
	    ->uri ('http://ws.lia')
	    ->proxy($SERVICE_LOCATION);




	my %request = ( 
         networkCharacteristic => $ARGV[0],
	 subject => SOAP::Data->type(map=> { source => SOAP::Data->type(map=> { address => SOAP::Data->type(map=> { name => $ARGV[1], }), }),
	              destination => SOAP::Data->type(map => { address => SOAP::Data->type (map => { name => $ARGV[2], }), })}),
         startTime => $ARGV[3],
         endTime => $ARGV[4],
         );

	
	 $rez =$result->networkMeasurementSet(SOAP::Data->type(map=>\%request));
	
	if ($rez->fault){
	    print "\n".$rez->faultstring."\n";	    
	} else {
	    $service=$rez->result();
	    print $service->{'networkMeasurements'}->{'results'}->{'resultSet'}->{'min'}."\n";
	    print $service->{'networkMeasurements'}->{'results'}->{'resultSet'}->{'avg'}."\n";
	    print $service->{'networkMeasurements'}->{'results'}->{'resultSet'}->{'max'}."\n";
	} # if - else
	
    } else {
	print "\n";
	print "Bad arguments "."\n\n";
	print "Arguments:  networkCharacteristic  sourceServiceName  destinationServiceName   fromTime[yyyy-MM-dd'T'hh:MM:ss]  toTime[yyyy-MM-dd'T'hh:MM:ss] <URL location of the wsdl service file(optional)>\n\n";
	print "Call example:\n./Client.pl \"path.delay.roundTrip\" \"SOURCE_FARM\" \"DEST_FARM\" \"2006-02-05T14:00:00\" \"2006-02-30T14:00:00\" \n\n";
    }   
    
