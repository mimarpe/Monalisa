
import org.apache.axis.AxisFault ;
import org.apache.axis.client.Call ;
import org.apache.axis.client.Service ; 
import org.apache.axis.utils.Options ;

import javax.xml.namespace.QName ;
import javax.xml.rpc.ParameterMode ;

import lia.ws.Result ;

import java.util.HashMap ;
import java.util.Iterator;
                                
public class Client
{
    public static void main(String [] args) throws Exception
    {

	// create the service
        Service  service = new Service();
	// create the call
        Call     call    = (Call) service.createCall();

        try {
            call.setTargetEndpointAddress( new java.net.URL(args[5]) );
	    
	    //the  function to be called	    
            call.setOperationName( new QName("MLWebService", "networkMeasurementSet") );
	    
            call.addParameter( "in0",org.apache.axis.encoding.XMLType.SOAP_MAP , ParameterMode.IN );

	    // set the type of the returned result
            call.setReturnType( org.apache.axis.encoding.XMLType.SOAP_MAP );

            HashMap req = new HashMap ();
	    
	    req.put ("networkCharacteristic", args[0]);

	    
	    HashMap nameS = new HashMap();
	    nameS.put ("name", args[1]);
	    HashMap addressS = new HashMap ();
	    addressS.put ("address", nameS);
	    HashMap sourceS = new HashMap ();
	    sourceS.put ("source", addressS);
	    HashMap nameD = new HashMap();
	    nameD.put ("name", args[2]);
	    HashMap addressD = new HashMap ();
	    addressD.put ("address", nameD);
	    HashMap sourceD = new HashMap ();
	    sourceS.put ("destination", addressD);
	    req.put("subject", sourceS);

	    
	    req.put ("startTime", args[3]) ; 
	    
	    req.put ("endTime", args[4]) ; 


	    //invoke the call
            HashMap result = (HashMap) call.invoke( new Object[] { req} );


	    if (result == null ){
		System.out.println ("Some error occured in accessing the database...");
		return;
	    }	
		   
	   System.out.println ("min: "+(((HashMap)(((HashMap)((HashMap)(result.get("networkMeasurements"))).get("results")).get("resultSet"))).get("min")));
	   System.out.println ("avg: "+(((HashMap)(((HashMap)((HashMap)(result.get("networkMeasurements"))).get("results")).get("resultSet"))).get("avg")));
	   System.out.println ("max: "+(((HashMap)(((HashMap)((HashMap)(result.get("networkMeasurements"))).get("results")).get("resultSet"))).get("max")));    
	   
	} catch (AxisFault fault) {
	    System.out.println (fault.getFaultString());
        } catch (Exception e) {
	    e.printStackTrace ();
	}
    }
}
