import lia.Monitor.monitor.*;

import java.io.*;
import java.util.*;
import java.net.InetAddress;


public class PBSjobs extends cmdExec implements  MonitoringModule {



//static String[] tmetric={"Running","Pending","Done/h","Exit/h"}; 
String[] tmetric;
String [] ijobs;
  
String cmd ;
String args;


public PBSjobs  () { 
   super( "PBSjobs");
   info.ResTypes = tmetric;
   System.out.println ( "Start the Interface to  PBS jobs " );
   isRepetitive = true;
}

public  MonModuleInfo init( MNode Node , String args ) {
    this.Node = Node;

    if ( args != null ) { 
      StringTokenizer tz = new StringTokenizer(args,",");
      int k = tz.countTokens();
      tmetric = new String [k*2];
      ijobs = new String[k];
      for ( int j=0; j < k; j ++ ) {
        String jname = tz.nextToken().trim();
        tmetric[2*j] = "Running_"+ jname;
        tmetric[2*j+1] = "Pending_"+jname;
        ijobs[j] = jname;
      }
    }
    info.ResTypes = tmetric;
    this.args = args;
	cmd=  "/usr/pbs/bin/qstat " ;
    return info;
}


public Object   doProcess() throws Exception  {
   BufferedReader buff1 = procOutput ( cmd );
  
  if ( buff1  == null ) {
    System.out.println ( " Failed  to get the  LSF output " );
    throw new Exception ( " PBS load  output  is null for " + Node.name);
  }


  return Parse(buff1);
}


public Result   Parse (  BufferedReader buff )  throws Exception  {

  Result rr = null ;
  rr = new Result(Node.getFarmName(), Node.getClusterName(), Node.getName(), null, tmetric );
    
  String lin;
  StringTokenizer tz;
  rr.time = (new Date()).getTime();

  try {
          lin = buff.readLine(); 
	  lin = buff.readLine();

        for ( ; ; ) {
             lin = buff.readLine();
             if ( lin == null ) break;
	     if ( lin.equals("") ) break;
             tz = new StringTokenizer ( lin ) ;
             int ni = tz.countTokens();
             if ( ni > 4 )  { 
               String pid = tz.nextToken().trim();
               String jname = tz.nextToken().trim();
               String user = tz.nextToken().trim();
               String usetime = tz.nextToken().trim();
               String status = tz.nextToken().trim();

               for ( int l=0; l < ijobs.length; l++ ) {
                 if ( jname.indexOf( ijobs[l]) != -1 ) {
                  
                   if ( status.equals("R"))  {
                      rr.param[2*l]++;
                   }
                   if ( status.equals("Q"))  {
                      rr.param[2*l+1]++;
                   }
                  
                   break;
                 }
              }

             }
        }
	buff.close();
	if ( pro != null ) pro.destroy();

             
             
     } catch ( Exception e ) { 
        System.out.println ( "Exeption in Parsing PBS output  Ex=" + e ); 
        throw e;
     }
  //System.out.println ( " ---> " +rr );
  return rr;

}

public MonModuleInfo getInfo(){
        return info;
}
public String[] ResTypes () {
  return tmetric;
}
public String getOsName() { return "linux"; }


static public void main ( String [] args ) {

  String host = "localhost" ;
  PBSjobs aa = new PBSjobs (); 
  String ad = null ;
  try {
    ad = InetAddress.getByName( host ).getHostAddress();
  } catch ( Exception e ) {
    System.out.println ( " Can not get ip for node " + e );
    System.exit(-1);
  }

  MonModuleInfo info = aa.init( new MNode (host ,ad,  null, null), "cmsim,ooHits");



 try  {
  Object bb = aa.doProcess();
 } catch ( Exception e ) {
   System.out.println ( " failed to process " );
 }



}
    
 
}


