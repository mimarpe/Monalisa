#!/bin/sh

#
# 
# DO NOT CHAGE THIS FILE!
# This script is called from CHECK_UPDATE and ML_SER
#
#

set_env() {

if [ -z "${PRGDIR}" ]; then
    echo 'This script assumes that variable PRGDIR is set'
    echo 'It should be called from the other scripts'
    return 1
fi

ML_ENV_FILE="${PRGDIR}"/"ml_env"

if [ -r "${ML_ENV_FILE}" ]; then
    . "${ML_ENV_FILE}"
else
    echo "Cannot find ${ML_ENV_FILE}"
    return 1
fi

if [ -z "${MONALISA_USER}" ]; then
	echo "Please set MONALISA_USER in ${ML_ENV_FILE}"
	echo "e.g MONALISA_USER=`id -u -n`"
	return 1
fi

if [ "`id -u`" = "0" ]; then
	echo "MonaLisa will not run as root"
	return 1
fi

if [ "`id -n -u`" != "${MONALISA_USER}" ]; then
	echo "Please login as ${MONALISA_USER} (as set in ${ML_ENV_FILE} ) and run this again."
	return 1
fi

if [ -z "${JAVA_HOME}" ]; then
    echo "Please set JAVA_HOME in ${ML_ENV_FILE}"
    return 1
fi

if [ ! -x "${JAVA_HOME}/bin/java" ]; then
    echo "Your JAVA_HOME ( ${JAVA_HOME} ) in ${ML_ENV_FILE} seems to be wrong"
    echo "Cannot execute ${JAVA_HOME}/bin/java"
    return 1
fi

if [ -z "${FARM_HOME}" ]; then
    echo "Please set FARM_HOME in ${ML_ENV_FILE}"
    return 1
fi

if [ ! -d "${FARM_HOME}" ]; then
    echo "Your FARM_HOME ( ${FARM_HOME} ) in ${ML_ENV_FILE} seems to be a wrong"
    echo "FARM_HOME should be a directory!"
    return 1
fi

if [ ! -r "${FARM_HOME}" ]; then
    echo "Your FARM_HOME ( ${FARM_HOME} ) in ${ML_ENV_FILE} seems to be a wrong"
    echo "${FARM_HOME}! does not have read access!"
    return 1
fi

if [ ! -w "${FARM_HOME}" ]; then
    echo "Your FARM_HOME ( ${FARM_HOME} ) in ${ML_ENV_FILE} seems to be a wrong"
    echo "${FARM_HOME}! does not have write access!"
    return 1
fi

ML_PID_FILE="${FARM_HOME}"/".ml.pid"

if [ -z "${FARM_CONF_FILE}" ]; then
    echo "Please set FARM_CONF_FILE in ${ML_ENV_FILE}"
    return 1
fi

if [ ! -r "${FARM_CONF_FILE}" ]; then
    echo "Your FARM_CONF_FILE ( ${FARM_CONF_FILE} ) in ${ML_ENV_FILE} seems to be wrong"
    echo "${FARM_CONF_FILE} does not have read access"
    return 1
fi

if [ -z "${FARM_NAME}" ]; then
    echo "Please set FARM_NAME in ${ML_ENV_FILE}"
    return 1
fi

if [ -z "${CACHE_DIR}" ]; then
    echo "Your CACHE_DIR ( ${CACHE_DIR} ) in ${ML_ENV_FILE} seems to be a wrong"
    echo "CACHE_DIR should be a directory!"
    return 1
fi

#maybe it's the first time with update...
if [ ! -d "${CACHE_DIR}" ]; then
    return 0
fi

if [ ! -r "${CACHE_DIR}" ]; then
    echo "Your CACHE_DIR ( ${CACHE_DIR} ) in ${ML_ENV_FILE} seems to be a wrong"
    echo "CACHE_DIR does not have read access!"
    return 1
fi
                                                                                                                                               
if [ ! -w "${CACHE_DIR}" ]; then
    echo "Your CACHE_DIR ( ${CACHE_DIR} ) in ${ML_ENV_FILE} seems to be a wrong"
    echo "CACHE_DIR does not have write access!"
    return 1
fi

}
